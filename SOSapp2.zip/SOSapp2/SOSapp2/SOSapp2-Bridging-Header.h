//
//  SOSapp2-Bridging-Header.h
//  SOSapp2
//
//  Created by faizan on 16/06/16.
//  Copyright © 2016 faizan. All rights reserved.
//

#ifndef SOSapp2_Bridging_Header_h
#define SOSapp2_Bridging_Header_h


#endif /* SOSapp2_Bridging_Header_h */
